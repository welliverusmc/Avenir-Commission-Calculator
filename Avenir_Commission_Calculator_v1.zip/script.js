const items=[
['New Line',50],['Upgrade',20],['BYOD',35],['Next Up',10],
['Extra',8],['Premium',11],['Individual Insurance',5],
['Family Insurance',7],['Internet AIR',50],['Watch',50],['Tablet',15]
];
const state={};
const c=document.getElementById('products');
items.forEach(([n,v])=>{
 state[n]=0;
 const d=document.createElement('div');
 d.className='card';
 d.innerHTML=`<span>${n}<br><small>$${v}</small></span>
 <div><button>-</button> <span id="${n}">0</span> <button>+</button></div>`;
 const b=d.querySelectorAll('button');
 b[0].onclick=()=>chg(n,-1,v);
 b[1].onclick=()=>chg(n,1,v);
 c.appendChild(d);
});
function chg(n,delta){
 state[n]=Math.max(0,state[n]+delta);
 document.getElementById(n).textContent=state[n];
 update();
}
function update(){
 let t=0;
 items.forEach(([n,v])=>t+=state[n]*v);
 document.getElementById('total').textContent='$'+t.toFixed(2);
}
function clearAll(){
 Object.keys(state).forEach(n=>{state[n]=0;document.getElementById(n).textContent=0;});
 update();
}